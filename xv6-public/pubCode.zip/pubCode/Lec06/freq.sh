cat iplists.txt |sort|uniq -c|sort
